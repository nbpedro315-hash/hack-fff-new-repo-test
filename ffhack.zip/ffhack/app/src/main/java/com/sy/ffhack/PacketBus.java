package com.sy.ffhack;

import java.util.ArrayList;
import java.util.List;

// Bus simples pra passar dados de pacote do VPN → OverlayService
public class PacketBus {

    public interface Listener {
        void onPacket(int srcPort, int dstPort, byte[] payload);
    }

    private static final List<Listener> listeners = new ArrayList<>();

    public static void addListener(Listener l) {
        synchronized (listeners) { listeners.add(l); }
    }

    public static void removeListener(Listener l) {
        synchronized (listeners) { listeners.remove(l); }
    }

    public static void onPacket(int srcPort, int dstPort, byte[] payload) {
        synchronized (listeners) {
            for (Listener l : listeners) {
                l.onPacket(srcPort, dstPort, payload);
            }
        }
    }
}
