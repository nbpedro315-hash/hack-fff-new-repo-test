package com.sy.ffhack;

// Dados de um inimigo detectado via pacote
public class EspData {
    public float screenX;   // posição na tela (0.0–1.0 relativo à largura)
    public float screenY;   // posição na tela (0.0–1.0 relativo à altura)
    public int health;      // 0–200
    public float distance;  // metros estimados
    public boolean visible; // linha de visão

    public EspData(float sx, float sy, int hp, float dist, boolean vis) {
        this.screenX = sx;
        this.screenY = sy;
        this.health = hp;
        this.distance = dist;
        this.visible = vis;
    }
}
