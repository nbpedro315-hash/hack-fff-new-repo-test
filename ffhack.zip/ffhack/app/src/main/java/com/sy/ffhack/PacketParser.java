package com.sy.ffhack;

import java.util.ArrayList;
import java.util.List;

/**
 * Heurística de parse dos pacotes UDP do Free Fire.
 * O protocolo Garena usa XOR simples com chave de sessão — sem a chave
 * exata, buscamos padrões de posição flutuante no payload.
 * Gotcha: a chave muda por sessão; isso detecta padrões estruturais.
 */
public class PacketParser {

    // Mínimo de bytes pra tentar parse
    private static final int MIN_LEN = 32;

    // Limites de posição de mundo Free Fire (ilha Bermuda ~5000x5000 unidades)
    private static final float WORLD_MIN = -3000f;
    private static final float WORLD_MAX = 7000f;
    private static final float HEIGHT_MIN = -50f;
    private static final float HEIGHT_MAX = 500f;

    public static List<EspData> tryParse(byte[] payload) {
        List<EspData> result = new ArrayList<>();
        if (payload == null || payload.length < MIN_LEN) return result;

        // Varre o payload buscando triplas de floats que parecem coordenadas 3D válidas
        for (int i = 0; i <= payload.length - 12; i++) {
            float x = readFloat(payload, i);
            float y = readFloat(payload, i + 4);
            float z = readFloat(payload, i + 8);

            if (isValidWorldPos(x, z, y)) {
                // Converte pos de mundo para pos de tela (projeção simplificada)
                float[] screen = worldToScreen(x, y, z);
                if (screen != null) {
                    // HP: busca byte próximo no range 0-200
                    int hp = 100; // default se não encontrar
                    if (i + 12 < payload.length) {
                        int raw = payload[i + 12] & 0xFF;
                        if (raw <= 200) hp = raw;
                    }
                    float dist = estimateDist(x, y, z);
                    result.add(new EspData(screen[0], screen[1], hp, dist, true));
                    i += 11; // pula os bytes já lidos
                }
            }
        }
        return result;
    }

    private static float readFloat(byte[] buf, int off) {
        int bits = ((buf[off] & 0xFF) << 24) |
                   ((buf[off+1] & 0xFF) << 16) |
                   ((buf[off+2] & 0xFF) << 8)  |
                    (buf[off+3] & 0xFF);
        return Float.intBitsToFloat(bits);
    }

    private static boolean isValidWorldPos(float x, float height, float z) {
        return x > WORLD_MIN && x < WORLD_MAX &&
               z > WORLD_MIN && z < WORLD_MAX &&
               height > HEIGHT_MIN && height < HEIGHT_MAX &&
               !Float.isNaN(x) && !Float.isNaN(z) && !Float.isNaN(height) &&
               !Float.isInfinite(x) && !Float.isInfinite(z);
    }

    // Projeção perspectiva simples — sem view matrix real
    // Assume câmera fixada no centro com FOV 60°
    private static final float FAKE_FOV = 60f;
    private static final float[] PLAYER_POS = {0f, 0f, 0f}; // será atualizado pelo aimbot

    private static float[] worldToScreen(float wx, float wy, float wz) {
        float dx = wx - PLAYER_POS[0];
        float dz = wz - PLAYER_POS[2];
        float dist = (float) Math.sqrt(dx*dx + dz*dz);
        if (dist < 1f) return null;

        // Ângulo horizontal
        float angleH = (float) Math.toDegrees(Math.atan2(dx, dz));
        float angleV = (float) Math.toDegrees(Math.atan2(wy - PLAYER_POS[1], dist));

        float halfFov = FAKE_FOV / 2f;
        if (Math.abs(angleH) > halfFov || Math.abs(angleV) > halfFov) return null;

        float sx = 0.5f + (angleH / FAKE_FOV);
        float sy = 0.5f - (angleV / FAKE_FOV);
        return new float[]{sx, sy};
    }

    private static float estimateDist(float wx, float wy, float wz) {
        float dx = wx - PLAYER_POS[0];
        float dy = wy - PLAYER_POS[1];
        float dz = wz - PLAYER_POS[2];
        return (float) Math.sqrt(dx*dx + dy*dy + dz*dz);
    }
}
