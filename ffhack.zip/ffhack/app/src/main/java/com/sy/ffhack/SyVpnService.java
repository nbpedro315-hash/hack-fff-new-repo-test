package com.sy.ffhack;

import android.content.Intent;
import android.net.VpnService;
import android.os.ParcelFileDescriptor;
import android.util.Log;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.InetAddress;
import java.nio.ByteBuffer;

public class SyVpnService extends VpnService {

    private static final String TAG = "SyVpnService";
    private ParcelFileDescriptor vpnInterface;
    private Thread vpnThread;
    private volatile boolean running = false;

    // Garena Free Fire usa UDP na porta 10012 e 10100
    private static final int FF_PORT_1 = 10012;
    private static final int FF_PORT_2 = 10100;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        setupVpn();
        return START_STICKY;
    }

    private void setupVpn() {
        try {
            Builder builder = new Builder();
            builder.setSession("SyHack VPN")
                   .addAddress("10.0.0.2", 32)
                   .addRoute("0.0.0.0", 0)
                   .addDnsServer("8.8.8.8")
                   // Captura só pacotes do Free Fire
                   .addAllowedApplication("com.dts.freefireth")
                   .addAllowedApplication("com.dts.freefiremax")
                   .setMtu(1500);

            vpnInterface = builder.establish();
            if (vpnInterface == null) {
                Log.e(TAG, "VPN interface null");
                return;
            }

            running = true;
            vpnThread = new Thread(this::runPacketLoop, "SyVpnThread");
            vpnThread.start();
            Log.d(TAG, "VPN ativa — interceptando Free Fire");

        } catch (Exception e) {
            Log.e(TAG, "Erro ao subir VPN: " + e.getMessage());
        }
    }

    private void runPacketLoop() {
        FileInputStream in = new FileInputStream(vpnInterface.getFileDescriptor());
        FileOutputStream out = new FileOutputStream(vpnInterface.getFileDescriptor());
        ByteBuffer packet = ByteBuffer.allocate(32767);

        while (running) {
            try {
                packet.clear();
                int len = in.read(packet.array());
                if (len <= 0) continue;
                packet.limit(len);

                // Parse básico do header IP
                byte[] raw = packet.array();
                int protocol = raw[9] & 0xFF; // 17 = UDP

                if (protocol == 17 && len > 28) {
                    // Header UDP: bytes 20-27
                    int srcPort = ((raw[20] & 0xFF) << 8) | (raw[21] & 0xFF);
                    int dstPort = ((raw[22] & 0xFF) << 8) | (raw[23] & 0xFF);

                    if (dstPort == FF_PORT_1 || dstPort == FF_PORT_2 ||
                        srcPort == FF_PORT_1 || srcPort == FF_PORT_2) {
                        // Pacote do Free Fire — envia para OverlayService processar
                        byte[] payload = new byte[len - 28];
                        System.arraycopy(raw, 28, payload, 0, payload.length);
                        PacketBus.onPacket(srcPort, dstPort, payload);
                    }
                }

                // Encaminha o pacote sem modificar (transparente)
                out.write(raw, 0, len);

            } catch (Exception e) {
                if (running) Log.e(TAG, "Erro no loop: " + e.getMessage());
            }
        }
    }

    @Override
    public void onDestroy() {
        running = false;
        if (vpnThread != null) vpnThread.interrupt();
        try {
            if (vpnInterface != null) vpnInterface.close();
        } catch (Exception ignored) {}
        super.onDestroy();
    }
}
