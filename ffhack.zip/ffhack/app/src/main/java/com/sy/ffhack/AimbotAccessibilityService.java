package com.sy.ffhack;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;

public class AimbotAccessibilityService extends AccessibilityService {

    private static AimbotAccessibilityService instance;
    private static boolean enabled = false;
    private int screenW, screenH;

    public static void setEnabled(boolean v) { enabled = v; }

    @Override
    public void onServiceConnected() {
        instance = this;
        WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        screenW = dm.widthPixels;
        screenH = dm.heightPixels;
    }

    /**
     * Dispara um swipe suave do centro da tela até a posição do alvo.
     * Simula o arrastar do dedo (mira) no joystick de visão do Free Fire.
     */
    public static void aimAt(EspData target) {
        if (instance == null || !enabled) return;

        float targetX = target.screenX * instance.screenW;
        float targetY = target.screenY * instance.screenH;
        float centerX = instance.screenW / 2f;
        float centerY = instance.screenH / 2f;

        // Calcula delta — quanto mover o joystick de câmera
        // O joystick de visão fica no lado direito da tela
        float joyX = instance.screenW * 0.75f; // posição X do joystick de câmera
        float joyY = instance.screenH * 0.6f;  // posição Y do joystick de câmera

        // Escala do movimento — quanto arrastar pra cada ângulo
        float scaleX = (targetX - centerX) / centerX * 80f;
        float scaleY = (targetY - centerY) / centerY * 80f;

        Path path = new Path();
        path.moveTo(joyX, joyY);
        path.lineTo(joyX + scaleX, joyY + scaleY);

        GestureDescription.StrokeDescription stroke =
            new GestureDescription.StrokeDescription(path, 0, 80); // 80ms de swipe suave

        GestureDescription gesture = new GestureDescription.Builder()
            .addStroke(stroke)
            .build();

        instance.dispatchGesture(gesture, null, null);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {}

    @Override
    public void onInterrupt() { instance = null; }

    @Override
    public void onDestroy() {
        instance = null;
        super.onDestroy();
    }
}
