package com.sy.ffhack;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import androidx.core.app.NotificationCompat;
import java.util.ArrayList;
import java.util.List;

public class OverlayService extends Service implements PacketBus.Listener {

    private static final String CH_ID = "sy_hack_channel";
    private WindowManager wm;

    // Painel principal
    private View panelView;
    private WindowManager.LayoutParams panelParams;
    private boolean panelVisible = true;

    // Botão minimizado (bolinha)
    private View miniBtn;
    private WindowManager.LayoutParams miniParams;

    // ESP overlay (cobre tela inteira, transparente)
    private EspView espView;
    private WindowManager.LayoutParams espParams;

    // Toggles
    private boolean espEnabled = true;
    private boolean aimbotEnabled = true;

    // Drag do painel
    private float dragStartX, dragStartY;
    private int panelInitX, panelInitY;

    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        startForeground(1, buildNotification());
        setupEspOverlay();
        setupPanel();
        setupMiniButton();
        PacketBus.addListener(this);
    }

    // ── ESP overlay ──────────────────────────────────────────────
    private void setupEspOverlay() {
        espView = new EspView(this);
        espParams = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE |
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        );
        wm.addView(espView, espParams);
    }

    // ── Painel flutuante ─────────────────────────────────────────
    private void setupPanel() {
        panelView = buildPanelView();

        panelParams = new WindowManager.LayoutParams(
            680, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        );
        panelParams.gravity = Gravity.TOP | Gravity.START;
        panelParams.x = 40;
        panelParams.y = 200;

        wm.addView(panelView, panelParams);
        setupPanelDrag();
    }

    private View buildPanelView() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xDD0A0A0A);
        root.setPadding(24, 16, 24, 20);

        // Título + botão fechar/minimizar
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = new TextView(this);
        title.setText("SY HACK");
        title.setTextColor(0xFFFF0033);
        title.setTextSize(18f);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        title.setLayoutParams(tp);

        Button btnMin = new Button(this);
        btnMin.setText("—");
        btnMin.setTextColor(Color.WHITE);
        btnMin.setBackgroundColor(0xFF333333);
        btnMin.setTextSize(14f);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(80, 60);
        bp.setMargins(8, 0, 0, 0);
        btnMin.setLayoutParams(bp);
        btnMin.setOnClickListener(v -> minimizePanel());

        header.addView(title);
        header.addView(btnMin);
        root.addView(header);

        // Divisor
        View div = new View(this);
        div.setBackgroundColor(0xFF333333);
        LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 2);
        dp.setMargins(0, 12, 0, 12);
        div.setLayoutParams(dp);
        root.addView(div);

        // Toggle ESP
        root.addView(buildToggle("ESP (Caixas de Inimigo)", espEnabled, v -> {
            espEnabled = ((Switch) v).isChecked();
            espView.setVisibility(espEnabled ? View.VISIBLE : View.GONE);
        }));

        // Toggle Aimbot
        root.addView(buildToggle("Aimbot (Auto Mira)", aimbotEnabled, v -> {
            aimbotEnabled = ((Switch) v).isChecked();
            AimbotAccessibilityService.setEnabled(aimbotEnabled);
        }));

        // Status de pacotes
        TextView pkStatus = new TextView(this);
        pkStatus.setText("Aguardando Free Fire...");
        pkStatus.setTextColor(0xFF888888);
        pkStatus.setTextSize(11f);
        pkStatus.setPadding(0, 12, 0, 0);
        pkStatus.setTag("pkStatus");
        root.addView(pkStatus);

        return root;
    }

    private View buildToggle(String label, boolean initial, View.OnClickListener listener) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rp.setMargins(0, 8, 0, 8);
        row.setLayoutParams(rp);

        TextView lbl = new TextView(this);
        lbl.setText(label);
        lbl.setTextColor(Color.WHITE);
        lbl.setTextSize(14f);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lbl.setLayoutParams(lp);

        Switch sw = new Switch(this);
        sw.setChecked(initial);
        sw.setOnClickListener(listener);

        row.addView(lbl);
        row.addView(sw);
        return row;
    }

    private void setupPanelDrag() {
        panelView.setOnTouchListener((v, e) -> {
            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    dragStartX = e.getRawX();
                    dragStartY = e.getRawY();
                    panelInitX = panelParams.x;
                    panelInitY = panelParams.y;
                    break;
                case MotionEvent.ACTION_MOVE:
                    panelParams.x = panelInitX + (int)(e.getRawX() - dragStartX);
                    panelParams.y = panelInitY + (int)(e.getRawY() - dragStartY);
                    wm.updateViewLayout(panelView, panelParams);
                    break;
            }
            return false;
        });
    }

    // ── Botão minimizado ─────────────────────────────────────────
    private void setupMiniButton() {
        TextView btn = new TextView(this);
        btn.setText("SY");
        btn.setTextColor(Color.WHITE);
        btn.setBackgroundColor(0xEEFF0033);
        btn.setTextSize(14f);
        btn.setTypeface(null, android.graphics.Typeface.BOLD);
        btn.setGravity(Gravity.CENTER);
        btn.setPadding(16, 10, 16, 10);
        btn.setOnClickListener(v -> expandPanel());

        miniParams = new WindowManager.LayoutParams(
            120, 80,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        );
        miniParams.gravity = Gravity.TOP | Gravity.END;
        miniParams.x = 20;
        miniParams.y = 300;

        miniBtn = btn;
        wm.addView(miniBtn, miniParams);
        miniBtn.setVisibility(View.GONE);
    }

    private void minimizePanel() {
        panelView.setVisibility(View.GONE);
        miniBtn.setVisibility(View.VISIBLE);
        panelVisible = false;
    }

    private void expandPanel() {
        panelView.setVisibility(View.VISIBLE);
        miniBtn.setVisibility(View.GONE);
        panelVisible = true;
    }

    // ── PacketBus — recebe pacotes do VPN ─────────────────────────
    @Override
    public void onPacket(int srcPort, int dstPort, byte[] payload) {
        if (!espEnabled) return;
        // Tenta parsear posições do payload Garena (heurística por padrão de bytes)
        List<EspData> detected = PacketParser.tryParse(payload);
        if (!detected.isEmpty()) {
            espView.setEnemies(detected);
            if (aimbotEnabled && !detected.isEmpty()) {
                AimbotAccessibilityService.aimAt(detected.get(0));
            }
        }
    }

    private Notification buildNotification() {
        NotificationChannel ch = new NotificationChannel(CH_ID, "Sy Hack", NotificationManager.IMPORTANCE_LOW);
        ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        return new NotificationCompat.Builder(this, CH_ID)
            .setContentTitle("Sy Hack ativo")
            .setContentText("ESP + Aimbot rodando")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build();
    }

    @Override
    public void onDestroy() {
        PacketBus.removeListener(this);
        if (espView != null) try { wm.removeView(espView); } catch (Exception ignored) {}
        if (panelView != null) try { wm.removeView(panelView); } catch (Exception ignored) {}
        if (miniBtn != null) try { wm.removeView(miniBtn); } catch (Exception ignored) {}
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
