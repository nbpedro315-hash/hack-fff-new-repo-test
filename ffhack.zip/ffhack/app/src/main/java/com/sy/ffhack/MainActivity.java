package com.sy.ffhack;

import android.content.Intent;
import android.net.VpnService;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final int VPN_REQUEST_CODE = 1001;
    private TextView tvStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvStatus = findViewById(R.id.tvStatus);
        Button btnActivate = findViewById(R.id.btnActivate);

        btnActivate.setOnClickListener(v -> {
            // 1. Pedir permissão de overlay se não tiver
            if (!Settings.canDrawOverlays(this)) {
                Intent intent = new Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    android.net.Uri.parse("package:" + getPackageName())
                );
                startActivityForResult(intent, 1002);
                return;
            }
            // 2. Pedir permissão VPN
            Intent vpnIntent = VpnService.prepare(this);
            if (vpnIntent != null) {
                startActivityForResult(vpnIntent, VPN_REQUEST_CODE);
            } else {
                // Já tem permissão — sobe tudo
                startHack();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == VPN_REQUEST_CODE && resultCode == RESULT_OK) {
            startHack();
        } else if (requestCode == 1002) {
            // Voltou da tela de overlay — tenta VPN agora
            if (Settings.canDrawOverlays(this)) {
                Intent vpnIntent = VpnService.prepare(this);
                if (vpnIntent != null) {
                    startActivityForResult(vpnIntent, VPN_REQUEST_CODE);
                } else {
                    startHack();
                }
            }
        }
    }

    private void startHack() {
        // Sobe VPN
        Intent vpn = new Intent(this, SyVpnService.class);
        startService(vpn);

        // Sobe overlay (painel flutuante)
        Intent overlay = new Intent(this, OverlayService.class);
        startForegroundService(overlay);

        tvStatus.setText("● ATIVO");
        tvStatus.setTextColor(0xFF00FF44);
    }
}
