package com.sy.ffhack;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.WindowManager;
import java.util.List;
import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArrayList;

public class EspView extends View {

    private final Paint boxPaint = new Paint();
    private final Paint linePaint = new Paint();
    private final Paint textPaint = new Paint();
    private final Paint healthPaint = new Paint();

    private final CopyOnWriteArrayList<EspData> enemies = new CopyOnWriteArrayList<>();
    private int screenW, screenH;

    public EspView(Context context) {
        super(context);
        init(context);
    }

    private void init(Context context) {
        // Dimensões da tela
        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        screenW = dm.widthPixels;
        screenH = dm.heightPixels;

        // Box ESP — vermelho
        boxPaint.setStyle(Paint.Style.STROKE);
        boxPaint.setColor(Color.RED);
        boxPaint.setStrokeWidth(3f);
        boxPaint.setAntiAlias(true);

        // Linha de sniper (aimbot visual)
        linePaint.setStyle(Paint.Style.STROKE);
        linePaint.setColor(0xAAFF0033);
        linePaint.setStrokeWidth(1.5f);
        linePaint.setAntiAlias(true);

        // Texto (distância, HP)
        textPaint.setColor(Color.WHITE);
        textPaint.setTextSize(28f);
        textPaint.setAntiAlias(true);
        textPaint.setShadowLayer(3f, 1f, 1f, Color.BLACK);

        // Barra de vida
        healthPaint.setStyle(Paint.Style.FILL);
        healthPaint.setAntiAlias(true);
    }

    public void setEnemies(List<EspData> list) {
        enemies.clear();
        enemies.addAll(list);
        postInvalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        float centerX = screenW / 2f;
        float centerY = screenH / 2f;

        for (EspData e : enemies) {
            float px = e.screenX * screenW;
            float py = e.screenY * screenH;

            // Altura do box proporcional à distância
            float boxH = Math.max(60f, 300f - (e.distance * 2f));
            float boxW = boxH * 0.5f;

            RectF box = new RectF(px - boxW / 2, py - boxH, px + boxW / 2, py);

            // Cor do box: vermelho se visível, amarelo se atrás
            boxPaint.setColor(e.visible ? Color.RED : Color.YELLOW);
            canvas.drawRect(box, boxPaint);

            // Barra de HP — verde → vermelho
            float hpRatio = e.health / 200f;
            healthPaint.setColor(hpColor(hpRatio));
            RectF hpBar = new RectF(box.left, box.top - 10f,
                                     box.left + (boxW * hpRatio), box.top - 4f);
            canvas.drawRect(hpBar, healthPaint);

            // Texto: distância
            canvas.drawText(String.format("%.0fm", e.distance), px - 20f, box.top - 14f, textPaint);

            // Linha do centro até o inimigo (aimbot visual)
            linePaint.setColor(e.visible ? 0xAAFF0033 : 0x44FFFF00);
            canvas.drawLine(centerX, centerY, px, py, linePaint);
        }
    }

    private int hpColor(float ratio) {
        int r = (int) (255 * (1f - ratio));
        int g = (int) (255 * ratio);
        return Color.rgb(r, g, 0);
    }
}
